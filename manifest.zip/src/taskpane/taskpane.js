/*
 * Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
 * See LICENSE in the project root for license information.
 */

/* global console, document, Excel, Office */

Office.onReady((info) => {
  if (info.host === Office.HostType.Excel) {
    document.getElementById("sideload-msg").style.display = "none";
    document.getElementById("app-body").style.display = "flex";
    document.getElementById("run").onclick = run;
  }
});

export async function run() {
  try {
    await Excel.run(async (context) => {
      /**
       * Insert your Excel code here
       */
      const range = context.workbook.getSelectedRange();

      // Read the range address
      range.load("address");

      // Update the fill color
      range.format.fill.color = "yellow";

      //Load metadata
      const customProps = context.workbook.properties.custom;
      const propProjectID = customProps.getItem("ProjectID");
      propProjectID.load("key,value");

      await context.sync();
      console.log(`ProjectID is  ${propProjectID.value}.`);

      var projectID = propProjectID.value;

      document.getElementById("powerAppsForm").src = "https://collablogic365.sharepoint.com/sites/SPServices/Test%20Document%20Set/Forms/EditForm.aspx?ID="+projectID;
      var iframeEle = document.querySelector('[title="Office Add-in OfficeAddIns"]');
      iframeEle.src = "https://collablogic365.sharepoint.com/sites/SPServices/Test%20Document%20Set/Forms/EditForm.aspx?ID="+projectID;
    });
  } catch (error) {
    console.error(error);
  }
}
